/*
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH under
 * one or more contributor license agreements. See the NOTICE file distributed
 * with this work for additional information regarding copyright ownership.
 * Licensed under the Camunda License 1.0. You may not use this file
 * except in compliance with the Camunda License 1.0.
 */
package io.camunda.optimize.service.db.es.writer;

import static io.camunda.optimize.service.db.DatabaseConstants.INSTANT_DASHBOARD_INDEX_NAME;

import co.elastic.clients.elasticsearch._types.FieldValue;
import co.elastic.clients.elasticsearch._types.Refresh;
import co.elastic.clients.elasticsearch._types.Result;
import co.elastic.clients.elasticsearch.core.BulkRequest;
import co.elastic.clients.elasticsearch.core.IndexResponse;
import co.elastic.clients.elasticsearch.core.SearchResponse;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.camunda.optimize.dto.optimize.query.dashboard.InstantDashboardDataDto;
import io.camunda.optimize.service.db.es.OptimizeElasticsearchClient;
import io.camunda.optimize.service.db.es.builders.OptimizeDeleteOperationBuilderES;
import io.camunda.optimize.service.db.es.builders.OptimizeIndexRequestBuilderES;
import io.camunda.optimize.service.db.es.builders.OptimizeSearchRequestBuilderES;
import io.camunda.optimize.service.db.writer.InstantDashboardMetadataWriter;
import io.camunda.optimize.service.exceptions.OptimizeRuntimeException;
import io.camunda.optimize.service.util.configuration.condition.ElasticSearchCondition;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Conditional;
import org.springframework.stereotype.Component;

@AllArgsConstructor
@Component
@Slf4j
@Conditional(ElasticSearchCondition.class)
public class InstantDashboardMetadataWriterES implements InstantDashboardMetadataWriter {

  private final OptimizeElasticsearchClient esClient;
  private final ObjectMapper objectMapper;

  @Override
  public void saveInstantDashboard(InstantDashboardDataDto dashboardDataDto) {
    log.debug("Writing new Instant preview dashboard to Elasticsearch");
    String id = dashboardDataDto.getInstantDashboardId();
    try {
      IndexResponse indexResponse =
          esClient.index(
              OptimizeIndexRequestBuilderES.of(
                  i ->
                      i.optimizeIndex(esClient, INSTANT_DASHBOARD_INDEX_NAME)
                          .id(id)
                          .document(dashboardDataDto)
                          .refresh(Refresh.True)));

      if (!indexResponse.result().equals(Result.Created)
          && !indexResponse.result().equals(Result.Updated)) {
        String message =
            "Could not write Instant preview dashboard data to Elasticsearch. "
                + "Maybe the connection to Elasticsearch got lost?";
        log.error(message);
        throw new OptimizeRuntimeException(message);
      }
    } catch (IOException e) {
      String errorMessage = "Could not write Instant preview dashboard data to Elasticsearch.";
      log.error(errorMessage, e);
      throw new OptimizeRuntimeException(errorMessage, e);
    }
    log.debug("Instant preview dashboard information with id [{}] has been created", id);
  }

  @Override
  public List<String> deleteOutdatedTemplateEntriesAndGetExistingDashboardIds(
      List<Long> hashesAllowed) throws IOException {
    List<String> dashboardIdsToBeDeleted = new ArrayList<>();
    SearchResponse<Map> searchResponse =
        esClient.search(
            OptimizeSearchRequestBuilderES.of(
                s ->
                    s.optimizeIndex(esClient, INSTANT_DASHBOARD_INDEX_NAME)
                        .query(
                            q ->
                                q.bool(
                                    b ->
                                        b.mustNot(
                                            m ->
                                                m.terms(
                                                    t ->
                                                        t.field(
                                                                InstantDashboardDataDto.Fields
                                                                    .templateHash)
                                                            .terms(
                                                                tt ->
                                                                    tt.value(
                                                                        hashesAllowed.stream()
                                                                            .map(FieldValue::of)
                                                                            .toList()))))))),
            Map.class);
    final BulkRequest.Builder bulkRequestBuilder = new BulkRequest.Builder();
    log.debug(
        "Deleting [{}] instant dashboard documents by id with bulk request.",
        searchResponse.hits().hits().size());
    searchResponse
        .hits()
        .hits()
        .forEach(
            hit -> {
              dashboardIdsToBeDeleted.add(
                  (String) hit.source().get(InstantDashboardDataDto.Fields.dashboardId));
              bulkRequestBuilder.operations(
                  o ->
                      o.delete(
                          OptimizeDeleteOperationBuilderES.of(
                              d ->
                                  d.optimizeIndex(esClient, INSTANT_DASHBOARD_INDEX_NAME)
                                      .id(hit.id()))));
            });
    esClient.doBulkRequest(
        searchResponse.hits().hits().isEmpty() ? null : bulkRequestBuilder.build(),
        INSTANT_DASHBOARD_INDEX_NAME,
        false);
    return dashboardIdsToBeDeleted;
  }
}
